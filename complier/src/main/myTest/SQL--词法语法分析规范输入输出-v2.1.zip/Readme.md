### v1.0

.sql文件为输入

.tsv文件为输出

详见https://docs.qq.com/doc/DQ3ZsZ0lQTWpMbUNU?u=002f2f67549d42708a83940ad2f13a63



### v2.0

修改了部分错误，包括0lexA.tsv中输出多余行，属性运算符“.”的序号错误，部分输出多余空格，字符串的引号等